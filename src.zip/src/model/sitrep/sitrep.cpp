#include "sitrep.h"

sitrep::sitrep(const QString& title, const QString& body)
    : m_title(title)
    , m_body(body)
{
}
