// OPS.h
#pragma once
#include "qek.h"

class OPS : public QEK {
public:
    // Sobreescribí solo lo que uses
    void execute20() override;
    void execute21() override;
    void execute22() override;
    void execute23() override;
    void execute24() override;
    void execute25() override;
    void execute26() override;
    void execute27() override;
    void execute30() override;
    void execute31() override;
    void execute32() override;
    void execute33() override;
    void execute34() override;
    void execute35() override;
    void execute36() override;
    void execute37() override;
    void execute40() override;
    void execute41() override;
    void execute42() override;
    void execute43() override;
    void execute44() override;
    void execute45() override;
    void execute46() override;
    void execute47() override;
    void execute50() override;
    void execute51() override;
    void execute52() override;
    void execute53() override;
    void execute54() override;
    void execute55() override;
    void execute56() override;
    void execute57() override;

};
